

<?php $__env->startSection('title', 'Material'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="row justify-content-center">
    <div class="col-12 col-md-12 text-center">
    <h1>Material</h1>
    <div class="row justify-content-center">
    <div class="col-12 col-md-3">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
    <div class="col-12 col-md-12 text-center">
    <p>List of materials, you can add more.</p>
    <div class="row justify-content-center">
     <div class="col-12 col-md-12">
        <div class="container">
        <div class="row justify-content-end">
            <div class="col-12 col-md-12">
                <div class="btn btn-primary">Agregar</div>
            </div>    
        </div>   

        <div class="row mt-3 justify-content-center">
            <div class="col-12 col-md-12">
                
                 <table class="table table-bordered table-hover">
                <thead class="thead-dark">
                    <th>#</th>
                    <th>Unity</th>
                    <th>Description</th>
                    <th>Unit Price</th>
                     <th>Actions</th>

                </thead>
                <tbody class="bg-white">
                    <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($material->id); ?></td>
                            <td><?php echo e($material->unit); ?></td>
                            <td><?php echo e($material->description); ?></td>
                            <td><?php echo e($material->unit_price); ?></td>
                            <td style="display:flex;">
                                <a class="btn btn-warning mr-2"><i class="fas fa-edit"></i></a>
                                <a class="btn btn-danger"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            </div>    
        </div> 
           
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\terraza\resources\views/dash/material.blade.php ENDPATH**/ ?>