

<?php $__env->startSection('title', 'Create Material'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="row justify-content-center">
    <div class="col-12 col-md-12 text-center">
    <h1>Create new Material</h1>
    <div class="row justify-content-center">
    <div class="col-12 col-md-3">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
    <div class="col-12 col-md-12 text-center">
    <p>From here you can add new material.</p>
    <div class="row justify-content-center">
     <div class="col-12 col-md-12">
        <div class="container">
        <div class="row justify-content-end">
            <div class="col-12 col-md-12">

                <form action="created" method="POST" class="mt-4">
                    <?php echo csrf_field(); ?>
                    <div class="row mb-3 justify-content-center">
                        <div class="col-12 col-md-3">
                                <label for="unity" class="form-label">Unit</label>
                                <input type="text" class="form-control" placeholder="Unit" name="unit" id="unit" tabindex="1" required>
                        </div>
                    </div>

                    <div class="row mb-3 justify-content-center">
                        <div class="col-12 col-md-6">
                            <label for="unity" class="form-label">Description</label>
                            <textarea type="text" class="form-control" placeholder="Type description here" name="description" id="description" tabindex="2" required></textarea>
                        </div>
                    </div>
                    
                    <div class="row mb-3 justify-content-center">
                        <div class="col-12 col-md-3">
                            <label for="unity" class="form-label">Unit price</label>
                            <input type="number" class="form-control" placeholder="0.00" name="unit_price" id="unit_price" tabindex="3" required>
                        </div>
                    </div>

                    <a href="../materials" class="btn btn-info mr-3">Cancel</a>
                    <button type="submit" class="btn btn-success" tabindex="4">Register</button>
                </form>
               
            </div>    
        </div>   

    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\terraza\resources\views/dash/categories/materials/create.blade.php ENDPATH**/ ?>