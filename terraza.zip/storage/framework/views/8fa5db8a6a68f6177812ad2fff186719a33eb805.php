

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="row justify-content-center">
    <div class="col-12 col-md-12 text-center">
    <h1>Equiptment</h1>
    <div class="row justify-content-center">
    <div class="col-12 col-md-3">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
    <div class="col-12 col-md-12 text-center">
    <p>List of equiptments, you can add more.</p>
    <div class="row justify-content-center">
    <div class="col-12 col-md-3">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\terraza\resources\views/dash/equiptment.blade.php ENDPATH**/ ?>