

<?php $__env->startSection('title', 'Labors'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="row justify-content-center">
    <div class="col-12 col-md-12 text-center">
    <h1>Labors</h1>
    <div class="row justify-content-center">
    <div class="col-12 col-md-3">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
    <div class="col-12 col-md-12 text-center">
    <p>List of labors, you can add more.</p>
    <div class="row justify-content-center">
     <div class="col-12 col-md-12">
        <div class="container">
        <div class="row justify-content-end">
            <div class="col-12 col-md-12">
                <a href="labors/create"><div class="btn btn-info">Add</div></a>
            </div>    
        </div>   

        <div class="row mt-3 justify-content-center">
            <div class="col-12 col-md-12">
                
                 <table id="labors_table" class="table table-bordered table-hover responsive">
                <thead class="thead-dark">
                    <tr>
                    <th>#</th>
                    <th>Unity</th>
                    <th>Description</th>
                    <th>Price per hour</th>
                     <th>Actions</th>
                    </tr>
                </thead>
               
            </table>

            </div>    
        </div> 
           
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if(session('eliminar') == 'ok'): ?>
     <script>
         Swal.fire(
            'Deleted!',
            'Your register has been deleted.',
            'success'
            )
     </script>
<?php endif; ?>

<?php if(session('actualizar') == 'ok'): ?>
     <script>
         Swal.fire(
            'Updated!',
            'Your register has been updated.',
            'success'
            )
     </script>
<?php endif; ?>

<?php if(session('agregar') == 'ok'): ?>
     <script>
         Swal.fire(
            'Added!',
            'Your register has been add.',
            'success'
            )
     </script>
<?php endif; ?>

<script>
 
 $("#labors_table").DataTable({
 
    processing: true,
    serverSide: true,
    "scrollY": "400px",
    "responsive" : true,
    "ajax": "<?php echo e(route('datatable.labor')); ?>",
    "language": {
            processing: '<i class="fa fa-spinner fa-spin fa-fw"></i><span class="sr-only">Loading...</span> '},
    "columns": [
        {data: 'id'},
        {data: 'unit'},
        {data: 'description'},
        {data: 'price_per_hour'},
        {data: 'actions'},
        /* {data: null, render: function(){
            return '<a class="btn btn-warning mr-2"><i class="fas fa-edit"></i></a>'+
                                '<button class="btn btn-danger"><i class="fas fa-trash"></i></button>'
        }}, */

    ]
     });


     function Llamar(e, id){
        e.preventDefault();
        form = $("#"+id);
        Swal.fire({
            
            title: 'Are you sure to remove this labor?',
            text: "You won't be able to revert this! id: " + id,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
            if (result.isConfirmed) {
            
            form.submit();
            }
            })
     }








</script>
            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\terraza\resources\views/dash/categories/labors/index.blade.php ENDPATH**/ ?>